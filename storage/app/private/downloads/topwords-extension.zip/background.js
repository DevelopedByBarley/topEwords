const APP_URL = 'https://topwords.eu';

// ── Közös fetch-wrapper ───────────────────────────────────────────────────────
// Minden szerverhívás ezen megy át. A HTTP státuszkódot tipizált hibakóddá
// alakítja, hogy a kliens ne félrevezető ágba fusson (pl. throttle 429 → „nincs
// az adatbázisban”). A válasz-törzsbeli error mező (ai_limit, plan, duplicate…)
// előnyben marad, mert az a legpontosabb — a státusz-alapú kód csak akkor jön,
// ha a szerver nem adott gépi hibakódot. Sosem dob: hiba esetén { error } objektum.
//
// Minden kérésnek van határideje. Enélkül egy félbemaradt (lógó) TCP-kapcsolat
// esetén a promise sosem oldódna fel, és a hívó felület spinnere — „Keresés…",
// „Paklik betöltése…", „Betöltés…" — örökre ott maradna, hibaüzenet nélkül.
// A megszakítást a fetch AbortError-ként dobja, amit a lenti catch a szokásos
// { error: 'network' }-re képez, így a kliensnek nincs új hibaágra szüksége.
const FETCH_TIMEOUT_MS = 15000;

function fetchJson(url, options = {}) {
    const { timeoutMs = FETCH_TIMEOUT_MS, ...fetchOptions } = options;

    return fetch(url, {
        credentials: 'include',
        signal: AbortSignal.timeout(timeoutMs),
        ...fetchOptions,
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            Accept: 'application/json',
            ...(fetchOptions.headers ?? {}),
        },
    })
        .then(async (r) => {
            const data = await r.json().catch(() => null);

            if (r.ok) {
                // A session-CSRF-token a munkamenet (és így a fiók) ujjlenyomata:
                // ha megváltozott, a tárolt szótérkép már egy másik munkamenethez
                // tartozik (lásd observeSessionToken).
                if (data && typeof data.csrf === 'string') {
                    observeSessionToken(data.csrf);
                }

                return data ?? { error: 'server' };
            }

            if (r.status === 401) {
                // A munkamenet megszűnt (kijelentkezés): a helyben tárolt
                // személyes szótérképet töröljük, ne maradjon a gépen. MINDEN
                // 401-re lefut — a body-beli error mező (a szerver a saját
                // {"error":"unauthenticated"} válaszát adja) előtt kell állnia,
                // különben a lenti ág visszatérne, és a purge el sem indulna.
                purgeStatusCache();

                return data && data.error ? data : { error: 'unauthenticated' };
            }

            if (data && data.error) {
                return data;
            }

            if (r.status === 403) {
                // A verified middleware megerősítetlen e-mailnél 403-at ad
                // (JSON-kérés → nincs HTML-redirect). A body-error ágra (plan,
                // ai_limit…) ez nem jut el, azt fentebb már visszaadtuk.
                return { error: 'unverified' };
            }

            if (r.status === 419) {
                return { error: 'csrf' };
            }

            if (r.status === 429) {
                return { error: 'rate_limit' };
            }

            return { error: 'server' };
        })
        .catch(() => ({ error: 'network' }));
}

// ── Státusz-cache ─────────────────────────────────────────────────────────────
// A szó→státusz térképet (GET_STATUSES) gyorsítótárazzuk, hogy az oldalkiemelés, a
// videófeliratok, a statisztika és a reconcile-tickek ne kérjék le minden alkalommal
// a szervertől. A cache a chrome.storage.local-ban él (túléli a service worker
// leállását is), egy memóriabeli másolattal a gyors elérésért. A szerver marad a
// forrás-igazság: minden sikeres írás (státuszváltás / új szó) érvényteleníti a
// cache-t, így a rá következő frissítés friss, teljes térképet tölt (a ragozott
// alakokkal együtt), TTL után pedig úgyis újratöltünk — így a más eszközön történt
// változások is bekerülnek.

const STATUS_CACHE_KEY = 'tw_statusCache';
const STATUS_CACHE_TTL = 5 * 60 * 1000; // 5 perc

// null = ismeretlen (a service worker most indult); egyébként { statuses, fetchedAt }.
// Érvénytelenítéskor „tombstone" kerül ide ({ statuses: null, fetchedAt: 0 }), hogy
// a memória maradjon a hiteles forrás, és ne olvassunk vissza elavult tárolt értéket.
let statusCacheMem = null;

function isFreshStatusCache(cache) {
    return Boolean(
        cache &&
        cache.statuses &&
        Date.now() - cache.fetchedAt < STATUS_CACHE_TTL,
    );
}

function readStatusCache() {
    if (statusCacheMem !== null) {
        return Promise.resolve(statusCacheMem);
    }

    return new Promise((resolve) => {
        chrome.storage.local.get({ [STATUS_CACHE_KEY]: null }, (data) => {
            statusCacheMem = data[STATUS_CACHE_KEY] ?? {
                statuses: null,
                fetchedAt: 0,
            };
            resolve(statusCacheMem);
        });
    });
}

// A fetchedAt alapból most; a foltozás a meglévőt adja át, hogy egy írás ne
// hosszabbítsa meg a TTL-t (különben a térkép — akár egy korábbi fiók foltokkal
// kevert térképe — írásonként újabb 5 percig élne a szerver megkérdezése nélkül).
function writeStatusCache(statuses, fetchedAt = Date.now()) {
    statusCacheMem = { statuses, fetchedAt };
    chrome.storage.local.set({ [STATUS_CACHE_KEY]: statusCacheMem });
}

// Érvénytelenítés: a memóriát azonnal (szinkron) tombstone-ra állítjuk, hogy a
// közvetlenül ezután érkező GET_STATUSES már biztosan frisset töltsön, és a tárolóba
// is tombstone-t írunk a service worker újraindulás esetére.
function invalidateStatusCache() {
    statusCacheMem = { statuses: null, fetchedAt: 0 };
    chrome.storage.local.set({ [STATUS_CACHE_KEY]: statusCacheMem });
}

// Teljes purge kijelentkezéskor: a szó→státusz térkép személyes tanulási adat,
// ezért ha a szerver 401-et ad (a munkamenet megszűnt / kijelentkezés), a tárolt
// másolatot ténylegesen töröljük a gépről, nem csak tombstone-ozzuk. Így közös
// gépen a következő fiók nem látja az előző user szótérképét.
function purgeStatusCache() {
    if (statusCacheMem === null || statusCacheMem.statuses !== null) {
        statusCacheMem = { statuses: null, fetchedAt: 0 };
        chrome.storage.local.remove(STATUS_CACHE_KEY);
    }
}

// Foltozás íráskor: a megváltozott szó felszíni alakjait helyben frissítjük a
// meglévő térképben, így a rákövetkező GET_STATUSES a memóriából szolgál ki, és
// NEM kell a teljes (akár több ezer soros) térképet újraletölteni — ez fogja
// vissza a szerverterhelést. Csak FRISS cache-t foltozunk: hideg/lejárt vagy üres
// cache-nél nincs mit foltozni (fél térképet írnánk), ezért invalidálunk, és a
// következő lekérés úgyis a teljes friss térképet tölti — vagyis nincs regresszió.
function patchStatusCache(forms, status) {
    if (!Array.isArray(forms) || forms.length === 0) {
        invalidateStatusCache();

        return Promise.resolve();
    }

    return readStatusCache().then((cache) => {
        if (!isFreshStatusCache(cache)) {
            invalidateStatusCache();

            return;
        }

        const next = { ...cache.statuses };

        for (const form of forms) {
            if (status) {
                next[form] = status;
            } else {
                delete next[form];
            }
        }

        writeStatusCache(next, cache.fetchedAt);
    });
}

// ── A cache fiókhoz (munkamenethez) kötése ────────────────────────────────────
// A szerver válaszaiban nincs fiók-azonosító, de a lookup/search a session-CSRF-
// tokent visszaadja. A Laravel ezt bejelentkezéskor (session()->regenerate()) és
// kijelentkezéskor (invalidate()) is újragenerálja, tehát egy MÁSIK fiók biztosan
// más tokent hoz. A tokennek csak a hash-ét tároljuk (nem magát a tokent), és ha
// eltér az utoljára látottól, a szótérképet eldobjuk: fiókváltás után a popup első
// kérése (vagy bármely szókeresés) már üríti az előző fiók térképét. Ugyanannak a
// fióknak az újra-bejelentkezése is ürít — ez csak egy fölösleges újratöltés.

const SESSION_FP_KEY = 'tw_sessionFp';

// undefined = még nem olvastuk be a tárolóból (a service worker most indult).
let sessionFpMem;

async function sessionFingerprint(token) {
    const digest = await crypto.subtle.digest(
        'SHA-256',
        new TextEncoder().encode(token),
    );

    return Array.from(new Uint8Array(digest).slice(0, 16))
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');
}

function readSessionFp() {
    if (sessionFpMem !== undefined) {
        return Promise.resolve(sessionFpMem);
    }

    return new Promise((resolve) => {
        chrome.storage.local.get({ [SESSION_FP_KEY]: null }, (data) => {
            // Közben egy párhuzamos observe már beállíthatta.
            if (sessionFpMem === undefined) {
                sessionFpMem = data[SESSION_FP_KEY] ?? null;
            }

            resolve(sessionFpMem);
        });
    });
}

function observeSessionToken(token) {
    if (!token) {
        return;
    }

    Promise.all([sessionFingerprint(token), readSessionFp()])
        .then(([fp, previous]) => {
            if (fp === previous) {
                return;
            }

            // Új munkamenet (bejelentkezés, fiókváltás, lejárt session) — a
            // korábbi munkamenetben betöltött térkép már nem a mostani fiókhoz
            // tartozik. Az első észlelésnél (previous = null) is ürítünk, mert
            // ilyenkor nem tudjuk, kié a tárolt térkép.
            sessionFpMem = fp;
            chrome.storage.local.set({ [SESSION_FP_KEY]: fp });
            purgeStatusCache();
        })
        .catch(() => {
            // A hash nem számolható (nem várt környezet) — nincs teendő.
        });
}

// Dokumentumonként (lap / újratöltés) az ELSŐ térkép-lekérés mindig a szerverhez
// megy, a cache-t megkerülve. Enélkül egy új lap kijelentkezés vagy fiókváltás után
// 0 kéréssel az előző fiók térképét kapná (a 401-es purge el sem indulna). Ugyanazon
// a dokumentumon belül (pl. YouTube SPA-navigáció, reconcile-tickek) a cache marad.
// A halmaz a chrome.storage.session-ben él: túléli a service worker gyakori
// (tétlenségi) leállását, a böngésző bezárásakor viszont törlődik, és content
// scriptből nem olvasható (alapértelmezett TRUSTED_CONTEXTS hozzáférés).
const STATUS_VALIDATED_DOCS_KEY = 'tw_statusValidatedDocs';
const STATUS_VALIDATED_DOCS_MAX = 500;

// null = még nem olvastuk be (a service worker most indult).
let statusValidatedDocs = null;

function statusDocKey(sender) {
    if (sender.documentId) {
        return sender.documentId;
    }

    return sender.tab ? `tab:${sender.tab.id}:${sender.frameId ?? 0}` : null;
}

function readStatusValidatedDocs() {
    if (statusValidatedDocs !== null) {
        return Promise.resolve(statusValidatedDocs);
    }

    return new Promise((resolve) => {
        const done = (list) => {
            // Közben egy párhuzamos jelölés már létrehozhatta.
            if (statusValidatedDocs === null) {
                statusValidatedDocs = new Set(Array.isArray(list) ? list : []);
            }

            resolve(statusValidatedDocs);
        };

        try {
            chrome.storage.session.get(
                { [STATUS_VALIDATED_DOCS_KEY]: [] },
                (data) => done(data?.[STATUS_VALIDATED_DOCS_KEY]),
            );
        } catch {
            done([]);
        }
    });
}

function markStatusDocValidated(docKey) {
    if (!docKey) {
        return;
    }

    readStatusValidatedDocs().then((docs) => {
        if (docs.size >= STATUS_VALIDATED_DOCS_MAX) {
            docs.clear();
        }

        docs.add(docKey);

        try {
            chrome.storage.session.set({
                [STATUS_VALIDATED_DOCS_KEY]: Array.from(docs),
            });
        } catch {
            // A session-tároló nem elérhető — a memóriabeli halmaz akkor is él.
        }
    });
}

// ── Context menus ─────────────────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(() => {
    // removeAll előbb: frissítéskor/újratöltéskor elkerüli a "duplicate id" hibát.
    chrome.contextMenus.removeAll(() => {
        chrome.contextMenus.create({
            id: 'lookup-word',
            title: 'Szó keresése: "%s"',
            contexts: ['selection'],
        });

        chrome.contextMenus.create({
            id: 'analyze-page',
            title: 'Oldal szövegelemzése',
            contexts: ['page', 'selection'],
        });
    });

    // A korábbi verziók számlálót írtak az ikonra. A badge-szöveg túléli a
    // frissítést, ezért egyszer letöröljük — különben egy régi szám örökre
    // ott ragadna az ikonon.
    chrome.action.setBadgeText({ text: '' });
});

// Context menu click handler
chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === 'lookup-word') {
        const word = (info.selectionText ?? '').trim().split(/\s+/)[0];

        if (!word) {
            return;
        }

        chrome.tabs.create({
            url: `${APP_URL}/words?search=${encodeURIComponent(word)}`,
        });
    }

    if (info.menuItemId === 'analyze-page') {
        if (!tab?.url) {
            return;
        }

        chrome.tabs.create({
            url: `${APP_URL}/text-analysis?url=${encodeURIComponent(tab.url)}`,
        });
    }
});

// ── Message handler (from content script) ────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    // Csak a saját extensionünk content scriptjeitől/popupjától fogadunk üzenetet
    // (defense-in-depth). Web-origin amúgy sem érheti el — nincs externally_connectable.
    if (sender.id !== chrome.runtime.id) {
        return;
    }

    if (msg.type === 'LOOKUP_WORD') {
        fetchJson(
            `${APP_URL}/extension/lookup?word=${encodeURIComponent(msg.word)}`,
        ).then((data) => sendResponse(data));

        return true; // keep channel open for async response
    }

    // Gyors státusz-állítás a kiemelt szóról, a popup megnyitása nélkül (dupla-
    // klikk / hosszú-nyomás gyorsbillentyűk). Egy körben: lookup a szóra, majd a
    // talált szó státuszának állítása a toggle-szemantikával (ha már a kért
    // státuszban van, levesszük). Ismeretlen szónál nem csinálunk semmit.
    if (msg.type === 'QUICK_STATUS') {
        fetchJson(
            `${APP_URL}/extension/lookup?word=${encodeURIComponent(msg.word)}`,
        ).then((look) => {
            if (!look || !look.found || !look.id) {
                sendResponse({ ok: false, error: look?.error ?? 'not_found' });

                return;
            }

            // A kért státuszt küldjük; a toggle-t (azonos státusz újraküldése =
            // levétel) a szerver végzi, ugyanúgy, mint a popup gombjainál.
            const url = look.is_custom
                ? `${APP_URL}/custom-words/${look.id}/status`
                : `${APP_URL}/words/${look.id}/status`;

            fetchJson(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': look.csrf,
                },
                body: JSON.stringify({ status: msg.status }),
            }).then(async (data) => {
                if (!data || data.error) {
                    sendResponse({ ok: false, error: data?.error });

                    return;
                }

                await patchStatusCache(data.forms, data.status ?? null);

                sendResponse({ ok: true, status: data.status ?? null });
            });
        });

        return true;
    }

    if (msg.type === 'ADD_WORD') {
        fetchJson(`${APP_URL}/extension/add-word`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': msg.csrf,
            },
            body: JSON.stringify({
                word: msg.word,
                meaning_hu: msg.meaning_hu,
                extra_meanings: msg.extra_meanings,
                synonyms: msg.synonyms,
                part_of_speech: msg.part_of_speech,
                example_en: msg.example_en,
                example_hu: msg.example_hu,
                form_base: msg.form_base,
                verb_past: msg.verb_past,
                verb_past_participle: msg.verb_past_participle,
                verb_present_participle: msg.verb_present_participle,
                verb_third_person: msg.verb_third_person,
                is_irregular: msg.is_irregular,
                noun_plural: msg.noun_plural,
                adj_comparative: msg.adj_comparative,
                adj_superlative: msg.adj_superlative,
                extra_forms: msg.extra_forms,
                status: msg.status,
                importance: msg.importance,
            }),
        }).then((data) => {
            // Új szó bekerült a szótárba — a térkép elavult, dobjuk a cache-t.
            if (data && data.ok) {
                invalidateStatusCache();
            }

            sendResponse(data);
        });

        return true;
    }

    if (msg.type === 'SEARCH_WORD') {
        fetchJson(
            `${APP_URL}/extension/search?q=${encodeURIComponent(msg.q)}`,
        ).then((data) => sendResponse(data));

        return true;
    }

    if (msg.type === 'GET_STATUSES') {
        const docKey = statusDocKey(sender);

        const fetchFresh = () => {
            fetchJson(`${APP_URL}/extension/statuses`).then((data) => {
                if (data && data.statuses) {
                    writeStatusCache(data.statuses);
                }

                // A szerver válaszolt (térképpel vagy 401-gyel, ami már purge-ölt):
                // ez a dokumentum innentől a cache-ből is kiszolgálható. Hálózati
                // hibánál nem jelöljük, a következő kérés újra a szervert kérdezi.
                if (data && (data.statuses || data.error === 'unauthenticated')) {
                    markStatusDocValidated(docKey);
                }

                sendResponse(data);
            });
        };

        // forceFresh: a fülre visszatéréskor (visibilitychange) megkerüljük a cache-t,
        // hogy a más eszközön/fülön végzett változások is azonnal látszódjanak.
        // Egy dokumentum első lekérése is friss (lásd statusValidatedDocs).
        if (msg.forceFresh || !docKey) {
            fetchFresh();

            return true;
        }

        Promise.all([readStatusValidatedDocs(), readStatusCache()]).then(([docs, cache]) => {
            if (docs.has(docKey) && isFreshStatusCache(cache)) {
                sendResponse({ statuses: cache.statuses });

                return;
            }

            fetchFresh();
        });

        return true;
    }

    if (msg.type === 'GET_YT_TRANSCRIPT') {
        // Ez a végpont a szerveren scrape-eli a YouTube-ot, ha a videó még nincs
        // gyorsítótárazva — érdemben tovább tart a többinél, ezért kap külön,
        // bővebb határidőt a közös 15 másodperc helyett.
        fetchJson(
            `${APP_URL}/extension/youtube-transcript?v=${encodeURIComponent(msg.videoId)}`,
            { timeoutMs: 45000 },
        ).then((data) => sendResponse(data));

        return true;
    }

    if (msg.type === 'UPDATE_STATUS') {
        const url = msg.is_custom
            ? `${APP_URL}/custom-words/${msg.id}/status`
            : `${APP_URL}/words/${msg.id}/status`;

        const body = msg.status
            ? JSON.stringify({ status: msg.status })
            : JSON.stringify({ status: '' });

        fetchJson(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': msg.csrf,
            },
            body,
        }).then(async (data) => {
            if (!data || data.error) {
                sendResponse({ ok: false, error: data?.error });

                return;
            }

            // A válasz tartalmazza a megváltozott szó összes felszíni alakját;
            // ezekkel helyben foltozzuk a cache-t (await: a content script
            // rákövetkező GET_STATUSES-e már a friss térképet lássa), így a
            // teljes újraletöltés elmarad.
            await patchStatusCache(data.forms, data.status ?? null);

            sendResponse({ ok: true, status: data.status ?? null });
        });

        return true;
    }

    if (msg.type === 'UPDATE_IMPORTANCE') {
        const url = msg.is_custom
            ? `${APP_URL}/custom-words/${msg.id}/importance`
            : `${APP_URL}/words/${msg.id}/importance`;

        fetchJson(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': msg.csrf,
            },
            body: JSON.stringify({ importance: msg.importance ?? null }),
        }).then((data) =>
            sendResponse({ ok: Boolean(data && !data.error), error: data?.error }),
        );

        return true;
    }

    if (msg.type === 'GET_DECKS') {
        fetchJson(`${APP_URL}/extension/decks`).then((data) =>
            sendResponse(data),
        );

        return true;
    }

    if (msg.type === 'CREATE_FLASHCARD') {
        fetchJson(`${APP_URL}/extension/create-flashcard`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': msg.csrf,
            },
            body: JSON.stringify(msg.card),
        }).then((data) => sendResponse(data));

        return true;
    }

    if (msg.type === 'GEMINI_FLASHCARD') {
        fetchJson(
            `${APP_URL}/text-analysis/gemini-flashcard?word=${encodeURIComponent(msg.word)}`,
        ).then((data) => sendResponse(data));

        return true;
    }

    if (msg.type === 'GEMINI_LOOKUP') {
        fetchJson(
            `${APP_URL}/text-analysis/gemini-lookup?word=${encodeURIComponent(msg.word)}`,
        ).then((data) => sendResponse(data));

        return true;
    }
});
